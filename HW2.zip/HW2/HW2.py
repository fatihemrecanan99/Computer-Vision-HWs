import matplotlib.pyplot as plt
import numpy as np
from sklearn.metrics import pairwise_distances
import cv2

def imagereading(image):
    img = cv2.imread(image, cv2.IMREAD_COLOR)
    return img
def find_match_and_compute_angle(rhistogram, ohistograms):
    mindistance = np.inf
    bestmatch = None
    bestshift = 0

    for shift in range(len(rhistogram)):
        shifted_histogram = np.roll(rhistogram, shift)
        distances = pairwise_distances([shifted_histogram], ohistograms, metric='euclidean')
        index = np.argmin(distances)
        distance = distances[0, index]

        if distance < mindistance:
            mindistance = distance
            bestmatch = index
            bestshift = shift

    angle = (bestshift / len(rhistogram)) * 360
    return bestmatch, angle

def edge_detection(image, lower_threshold, upper_threshold):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, lower_threshold, upper_threshold)
    return edges
def line_fitting(edges, threshold, min_line_length, max_line_gap):
    lines = cv2.HoughLinesP(edges, 1, np.pi/180, threshold, minLineLength=min_line_length, maxLineGap=max_line_gap)
    return lines


def compute_orientation_histogram(lines, n_bins):
    orient = []
    leng = []

    if lines is None:
        return np.zeros(n_bins)

    for line in lines:
        x1, y1, x2, y2 = line[0]
        orientation = np.arctan2(y2 - y1, x2 - x1)
        length = np.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
        orient.append(orientation)
        leng.append(length)

    histogram, _ = np.histogram(orient, bins=n_bins, range=(-np.pi, np.pi), weights=leng)
    return histogram


def match_and_compute_angle(rotated_histograms, original_histograms):
    match = []
    angles = []

    for rotated_histogram in rotated_histograms:
        mindist = np.inf
        bestmatch = None
        bestshift = 0

        for shift in range(len(rotated_histogram)):
            shifted_histogram = np.roll(rotated_histogram, shift)
            distances = pairwise_distances([shifted_histogram], original_histograms, metric='euclidean')
            index = np.argmin(distances)
            dist = distances[0, index]

            if dist < mindist:
                mindist = dist
                bestmatch = index
                bestshift = shift

        match.append(bestmatch)
        angle = (bestshift / len(rotated_histogram)) * 360
        angles.append(angle)

    return match, angles
def draw_lines_on_image(image, lines):
    copyimg = image.copy()
    for i in lines:
        x1, y1, x2, y2 = i[0]
        cv2.i(copyimg, (x1, y1), (x2, y2), (0, 255, 0), 2)
    return copyimg

# Set parameters
canlowthreshold = 100
canupthreshold = 200
houghthreshold = 50
minlen = 20
maxgap = 5
n_bins = 36

# Example usage:
originalimage = 'ters.png'
rotatedimage = 'tersR.png'

originalimg = imagereading(originalimage)
rotatedimg = imagereading(rotatedimage)

# Process images
edgeimgO = edge_detection(originalimg, canlowthreshold, canupthreshold)
edgeimgR = edge_detection(rotatedimg, canlowthreshold, canupthreshold)

linesO = line_fitting(edgeimgO, houghthreshold, minlen, maxgap)
linesR = line_fitting(edgeimgR, houghthreshold, minlen, maxgap)

histogramO = compute_orientation_histogram(linesO, n_bins)
histogramR = compute_orientation_histogram(linesR, n_bins)

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4))
ax1.bar(range(n_bins), histogramO)
ax2.bar(range(n_bins), histogramR)
ax1.set_title("Original Histogram")
ax2.set_title("Rotated Histogram")
plt.show()

withlinesO = draw_lines_on_image(originalimg, linesO)
withlinesR = draw_lines_on_image(rotatedimg, linesR)

# Create a 2x3 grid of plots
fig, axes = plt.subplots(2, 3, figsize=(15, 10))

# Display original image
axes[0, 0].imshow(cv2.cvtColor(originalimg, cv2.COLOR_BGR2RGB))
axes[0, 0].set_title("Original Image")

# Display rotated image
axes[0, 1].imshow(cv2.cvtColor(rotatedimg, cv2.COLOR_BGR2RGB))
axes[0, 1].set_title("Rotated Image")

# Display original edge image
axes[0, 2].imshow(edgeimgO, cmap='gray')
axes[0, 2].set_title("Original Edge Image")

# Display rotated edge image
axes[1, 0].imshow(edgeimgR, cmap='gray')
axes[1, 0].set_title("Rotated Edge Image")

# Display original image with lines
axes[1, 1].imshow(cv2.cvtColor(withlinesO, cv2.COLOR_BGR2RGB))
axes[1, 1].set_title("Original Image with Lines")

# Display rotated image with lines
axes[1, 2].imshow(cv2.cvtColor(withlinesR, cv2.COLOR_BGR2RGB))
axes[1, 2].set_title("Rotated Image with Lines")

# Remove axis labels
for ax in axes.ravel():
    ax.axis('off')
plt.show()