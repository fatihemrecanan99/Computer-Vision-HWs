from skimage.segmentation import slic
from skimage.io import imread
import matplotlib.pyplot as plt
from skimage.segmentation import mark_boundaries
from skimage.filters import gabor
from skimage import color
import cv2
import numpy as np
from sklearn.cluster import KMeans
from skimage.segmentation import find_boundaries

img = imread('4.jpg')

segmented = slic(img, n_segments=100, compactness=10)

plt.imshow(mark_boundaries(img,segmented))
plt.show()


gryimg = color.rgb2gray(img)


real, imag = gabor(gryimg, frequency=0.6)

magnt = np.sqrt(real**2 + imag**2)

plt.imshow(magnt, cmap='gray')
plt.show()


pxl = np.float32(img.reshape(-1, 3))

criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 100, 0.2)
k = 8
_, labels, centers = cv2.kmeans(pxl, k, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)

cntr = np.uint8(centers)

segmentimg = cntr[labels.flatten()]

segmentimg = segmentimg.reshape(img.shape)

plt.imshow(segmentimg)
plt.show()

def findingneigh(superpxl, segments):
    boundaries = find_boundaries(segments == superpxl)
    neighbours = np.unique(segments[boundaries])
    return neighbours

def findfeaturevec(superpxel, img, segments):
    return np.mean(img[segments == superpxel], axis=0)

superpxl = np.unique(segmented)

contxtualvctrs = []

for superpixel in superpxl:
    neighs = findingneigh(superpixel, segmented)

    superpxlvctr = findfeaturevec(superpixel, img, segmented)

    neighvctr = [findfeaturevec(neighbour, img, segmented) for neighbour in neighs]
    aveneighvctr = np.mean(neighvctr, axis=0)

    contxtvctr = np.concatenate([superpxlvctr, aveneighvctr])

    contxtualvctrs.append(contxtvctr)

contxtualvctrs = np.array(contxtualvctrs)

kmeans = KMeans(n_clusters=8, random_state=0).fit(contxtualvctrs)

clusterlbls = kmeans.labels_

clusimg = np.zeros_like(segmented)
for superpixel, label in zip(superpxl, clusterlbls):
    clusimg[segmented == superpixel] = label

plt.imshow(clusimg)
plt.show()
